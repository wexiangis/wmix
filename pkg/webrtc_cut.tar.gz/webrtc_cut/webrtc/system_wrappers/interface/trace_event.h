// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file under third_party_mods/chromium or at:
// http://src.chromium.org/svn/trunk/src/LICENSE

#ifndef WEBRTC_SYSTEM_WRAPPERS_INTERFACE_TRACE_EVENT_H_
#define WEBRTC_SYSTEM_WRAPPERS_INTERFACE_TRACE_EVENT_H_

// This file has moved.
// TODO(tommi): Delete after removing dependencies and updating Chromium.
#include "webrtc/base/trace_event.h"

#endif  // WEBRTC_SYSTEM_WRAPPERS_INTERFACE_TRACE_EVENT_H_
