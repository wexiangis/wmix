
# 编译

* make libs

* make

# 运行(先拷贝 ./install/lib/*.so 到系统)

* ./out

