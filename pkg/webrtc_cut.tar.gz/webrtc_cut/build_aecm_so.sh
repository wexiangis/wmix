
## 源文件列表
src=""

src_dir() {
    for i in `ls $1`;do
        case $i in
        *.c)
            ## 排除文件
            if [ "$i" == "aecm_core_mips.c" ];then
                continue
            elif [ "$i" == "aecm_core_neon.c" ];then
                continue
            fi
            ## 添加文件到列表
            src=$src"$1$i "
            echo "$1$i "
            ;;
        esac
    done
}

soName=libwebrtcaecm
srcPath=aecm

## 按目录添加.c文件到列表
src_dir "webrtc/modules/audio_processing/$srcPath/"
src_dir "webrtc/modules/audio_processing/utility/"
src_dir "webrtc/common_audio/"

src=$src"webrtc/system_wrappers/source/cpu_features.cc "

echo " ------------------- all file ------------------"
#exit 0

## 宏定义
def="-DWEBRTC_POSIX "

## 编译器
GCC=gcc
#GCC=arm-linux-gnueabihf-gcc

if [ $# -gt 0 ];then
    GCC=$1
fi

## build .so
$GCC -fPIC -shared -o $soName.so $src -I./ $def -lpthread -lm
## build .a
#${arm}ar rcs -o $soName.a $source -I./

## 创建install目录并拷贝目标文件
installPath=./install
mkdir $installPath/lib -p
mkdir $installPath/include/webrtc -p
mv ./$soName.* $installPath/lib
cp ./webrtc/typedefs.h $installPath/include/webrtc
cp ./webrtc/modules/audio_processing/$srcPath/include/* $installPath/include/

