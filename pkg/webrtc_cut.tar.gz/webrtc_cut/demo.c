
#include <stdio.h>

// vad
#include "webrtc_vad.h"
//aec
#include "echo_cancellation.h"
//aecm
#include "echo_control_mobile.h"
//ns
#include "noise_suppression.h"
#include "noise_suppression_x.h"

void help(char *name){
    printf("\r\n"
        "Usage: \r\n"
        "\r\n"
        );
}

void main(int argc, char **argv){
    
    int ret = 0;
    
    VadInst* handle;
    void *aecInst;
    void *aecmInst;
    NsHandle *NS_inst;
    NsxHandle *nsxInst;
    
    int16_t audio_frame[160] = {0};
    
    // ---------- ns ---------
    
    // 创建句柄
    ret = WebRtcNs_Create(&NS_inst);
    printf("WebRtcNs_Create: ret %d\r\n", ret);
    
    // 回收内存
    ret = WebRtcNs_Free(NS_inst);
    printf("WebRtcNs_Free: ret %d\r\n", ret);
    
    // ---------- nsx ---------
    
    // 创建句柄
    ret = WebRtcNsx_Create(&nsxInst);
    printf("WebRtcNsx_Create: ret %d\r\n", ret);
    
    // 回收内存
    ret = WebRtcNsx_Free(nsxInst);
    printf("WebRtcNsx_Free: ret %d\r\n", ret);
    
    // ---------- aecm ---------
    
    // 创建句柄
    ret = WebRtcAecm_Create(&aecmInst);
    printf("WebRtcAecm_Create: ret %d\r\n", ret);
    
    // 初始化句柄
    ret = WebRtcAecm_Init(aecmInst, 8000);
    printf("WebRtcAecm_Init: ret %d\r\n", ret);
    
    // 回收内存
    ret = WebRtcAecm_Free(aecmInst);
    printf("WebRtcAecm_Free: ret %d\r\n", ret);
    
    // ---------- aec ---------
    
    // 创建句柄
    ret = WebRtcAec_Create(&aecInst);
    printf("WebRtcAec_Create: ret %d\r\n", ret);
    
    // 初始化句柄
    ret = WebRtcAec_Init(aecInst, 8000, 8000);
    printf("WebRtcAec_Init: ret %d\r\n", ret);
    
    // 回收内存
    ret = WebRtcAec_Free(aecInst);
    printf("WebRtcAec_Free: ret %d\r\n", ret);
    
    // ---------- vad ---------
    
    // 创建句柄
    ret = WebRtcVad_Create(&handle);
    printf("WebRtcVad_Create: ret %d\r\n", ret);
    
    // 初始化句柄
    ret = WebRtcVad_Init(handle);
    printf("WebRtcVad_Init: ret %d\r\n", ret);
    
    // 设置模式
    // 0 (High quality) - 3 (Highly aggressive), 数字越大越激进
    ret = WebRtcVad_set_mode(handle, 0);
    printf("WebRtcVad_set_mode: ret %d\r\n", ret);

    // 数据处理
    // 8000Hz 20ms 采样间隔时, 每包160帧, 每帧2字节
    ret = WebRtcVad_Process(handle, 8000, audio_frame, 160);
    printf("WebRtcVad_Process: ret %d\r\n", ret);
    
    // 采样频率8000/16000/32000/48000Hz 和 每次解析帧数的组合 frame_length 是否合法
    // 即 WebRtcVad_Process(x,x,frame_length) 里面的 frame_length
    // 示例:
    //     8000Hz, 16bit, 间隔20ms, 则 frame_length = 8000/1000*20 = 160 frame (每帧2字节,用的 int16_t*)
    //     16000Hz, 16bit, 间隔30ms, 则 frame_length = 16000/1000*30 = 480 frame
    ret = WebRtcVad_ValidRateAndFrameLength(8000, 160);
    printf("WebRtcVad_ValidRateAndFrameLength: ret %d\r\n", ret);
    
    // 回收内存
    WebRtcVad_Free(handle);
}

