
## 源文件列表
src=""

src_dir() {
    for i in `ls $1`;do
        case $i in
        *.c)
            ## 排除文件
            if [ "$i" == "complex_bit_reverse_mips.c" ];then
                continue
            elif [ "$i" == "complex_fft_mips.c" ];then
                continue
            elif [ "$i" == "cross_correlation_mips.c" ];then
                continue
            elif [ "$i" == "cross_correlation_neon.c" ];then
                continue
            elif [ "$i" == "downsample_fast_mips.c" ];then
                continue
            elif [ "$i" == "downsample_fast_neon.c" ];then
                continue
            elif [ "$i" == "filter_ar_fast_q12_mips.c" ];then
                continue
            elif [ "$i" == "min_max_operations_mips.c" ];then
                continue
            elif [ "$i" == "min_max_operations_neon.c" ];then
                continue
            elif [ "$i" == "spl_sqrt_floor_mips.c" ];then
                continue
            elif [ "$i" == "vector_scaling_operations_mips.c" ];then
                continue
            fi
            ## 添加文件到列表
            src=$src"$1$i "
            echo "$1$i "
            ;;
        esac
    done
}

## 按目录添加.c文件到列表
src_dir "webrtc/common_audio/vad/"
src_dir "webrtc/common_audio/signal_processing/"

echo " ------------------- all file ------------------"
#exit 0

## 宏定义
def="-DWEBRTC_POSIX "

## 编译器
GCC=gcc
#GCC=arm-linux-gnueabihf-gcc

if [ $# -gt 0 ];then
    GCC=$1
fi

## build .so
$GCC -fPIC -shared -o libWebRtcVad.so $src -I./ $def -lpthread
## build .a
#ar rcs -o libWebRtcVad.a $source -I./

## 创建install目录并拷贝目标文件
installPath=./install
mkdir ${installPath}/lib -p
mkdir ${installPath}/include/webrtc -p
cp ./libWebRtcVad.* ${installPath}/lib
cp ./webrtc/typedefs.h ${installPath}/include/webrtc
cp ./webrtc/common_audio/vad/include/webrtc_vad.h ${installPath}/include

